'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildSystem } = require('../src/401_system');

function freshDataDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'cvos-test-'));
}

function readyConcept(sys, text = 'Behind the scenes of a community garden harvest') {
  const idea = sys.contentIdeaEngine.promoteContentIdea(
    sys.contentIdeaEngine.createContentIdea(text).id
  );
  return sys.contentConceptEngine.createContentConcept(idea);
}

let assetNonce = 0;
function importedAsset(sys, overrides = {}) {
  // See 611_editPlanEngine.test.js for why this must be unique per call
  // (importMedia short-circuits on a content hash, 207_MediaEngine.js).
  assetNonce += 1;
  return sys.mediaEngine.importMedia(Object.assign(
    { binaryContent: Buffer.from('slice5 editengine test bytes ' + assetNonce), mediaType: 'video', durationSec: 6, orientation: 'vertical' },
    overrides
  ));
}

function analyzedAsset(sys) {
  const asset = importedAsset(sys);
  sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  return sys.storage.read('media_assets', asset.id);
}

function readyPlan(sys, { assetCount = 2 } = {}) {
  const concept = readyConcept(sys);
  const assets = [];
  for (let i = 0; i < assetCount; i += 1) assets.push(analyzedAsset(sys));
  const plan = sys.editPlanEngine.createEditPlan({
    conceptId: concept.id,
    mediaAssetIds: assets.map((a) => a.id),
  });
  return { concept, assets, plan };
}

// --- Execution boundary (Contract v1 §6/§9, ADR-022) ----------------------

test('generateRoughCut: succeeds and produces an EditVersion for a current/valid READY EditPlan', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys);

  const version = sys.editEngine.generateRoughCut(plan.id);

  assert.equal(version.edit_plan_id, plan.id);
  assert.equal(typeof version.id, 'string');
  assert.equal(typeof version.generated_at, 'string');
  assert.ok(version.manifest);
  assert.deepEqual(sys.editEngine.get(version.id), version);
});

test('generateRoughCut: HALTS on a stale EditPlan — no EditVersion is produced', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 1 });
  sys.mediaAnalysisEngine.analyzeMedia(assets[0].id); // plan is now stale

  assert.throws(() => sys.editEngine.generateRoughCut(plan.id), /stale/);
  assert.equal(sys.editEngine.getAllForPlan(plan.id).length, 0, 'no EditVersion may be produced when blocked');
});

test('generateRoughCut: HALTS on an unverifiable EditPlan — no EditVersion is produced', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const neverAnalyzed = importedAsset(sys);
  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [neverAnalyzed.id] });

  assert.throws(() => sys.editEngine.generateRoughCut(plan.id), /unverifiable/);
  assert.equal(sys.editEngine.getAllForPlan(plan.id).length, 0);
});

test('generateRoughCut: no silent repair — a blocked (stale) attempt leaves the EditPlan\'s own provenance completely untouched', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 1 });
  sys.mediaAnalysisEngine.analyzeMedia(assets[0].id);
  const planBefore = JSON.parse(JSON.stringify(sys.editPlanEngine.get(plan.id)));

  assert.throws(() => sys.editEngine.generateRoughCut(plan.id));

  assert.deepEqual(sys.editPlanEngine.get(plan.id), planBefore);
  assert.equal(sys.editPlanEngine.checkProvenance(plan.id).status, 'stale', 'must remain stale — never auto-refreshed by a blocked execution attempt');
});

test('generateRoughCut: rejects a non-READY EditPlan (GENERATION_FAILED), independent of provenance', () => {
  const { MockAIProvider } = require('../src/adapters/302_MockAIProvider');
  const failingProvider = new MockAIProvider();
  failingProvider.generateEditPlan = () => ({ selected_clips: [] }); // fails validation: selected_clips must be non-empty

  const sys = buildSystem(freshDataDir(), { aiProvider: failingProvider });
  const concept = readyConcept(sys);
  const asset = importedAsset(sys);
  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [asset.id] });

  assert.equal(plan.status, 'GENERATION_FAILED');
  assert.throws(() => sys.editEngine.generateRoughCut(plan.id), /requires READY/);
});

// --- Manifest determinism / ordering (Contract v1 §7/§10) -----------------

test('EditEngine manifest: timeline follows each clip\'s own `order`, not selected_clips insertion order', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const a = analyzedAsset(sys);
  const b = analyzedAsset(sys);

  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [a.id, b.id] });
  // Force an out-of-order `order` to prove the manifest re-sorts rather than trusting array position.
  const reordered = plan.selected_clips.slice().reverse().map((c, i) => Object.assign({}, c, { order: i }));
  sys.storage.update('edit_plans', plan.id, { selected_clips: reordered });

  const version = sys.editEngine.generateRoughCut(plan.id);
  assert.deepEqual(version.manifest.timeline.map((t) => t.asset_id), reordered.slice().sort((x, y) => x.order - y.order).map((c) => c.asset_id));
});

test('EditEngine manifest: deterministic — two generateRoughCut calls on the same valid plan produce identical manifest content', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys);

  const v1 = sys.editEngine.generateRoughCut(plan.id);
  const v2 = sys.editEngine.generateRoughCut(plan.id);

  assert.notEqual(v1.id, v2.id, 'each call still produces its own EditVersion record');
  assert.deepEqual(v1.manifest, v2.manifest, 'manifest content itself must be a deterministic function of the plan');
});

test('EditEngine manifest: is a structured object, not a rendered file — no binary/file output of any kind', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys);
  const version = sys.editEngine.generateRoughCut(plan.id);

  assert.equal(typeof version.manifest, 'object');
  assert.equal(Buffer.isBuffer(version.manifest), false);
  assert.ok(Array.isArray(version.manifest.timeline));
});

// --- Authority boundary static checks (mirrors 610_'s pattern) ------------

test('EditEngine source introduces no port/provider abstraction and no Slice 6/Google-API/publication-authority concepts', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/210_EditEngine.js'), 'utf8');
  [
    'ReviewEngine', 'FINAL_APPROVED', 'PUBLISHED', 'PublicationEngine',
    'SpreadsheetApp', 'DriveApp', 'UrlFetchApp', 'VideoProvider', 'RenderPort',
  ].forEach((term) => assert.equal(source.includes(term), false, 'unexpected term in EditEngine: ' + term));

  const ports = fs.readFileSync(path.join(__dirname, '../src/001_ports.js'), 'utf8');
  assert.equal(/class\s+\w*Video\w*Port/.test(ports), false, 'no video-rendering port class may exist yet (Contract v1 §7/§11, Issue-04)');
});

test('EditEngine never marks its own output as FINAL_APPROVED or PUBLISHED, and does not accept/emit anything resembling cross-OS execution', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys);
  const version = sys.editEngine.generateRoughCut(plan.id);

  const serialized = JSON.stringify(version);
  assert.equal(serialized.includes('FINAL_APPROVED'), false);
  assert.equal(serialized.includes('PUBLISHED'), false);
});
