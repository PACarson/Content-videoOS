'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildSystem } = require('../src/401_system');
const EditPlan = require('../src/112_EditPlan');

function freshDataDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'cvos-test-'));
}

function readyConcept(sys, text = 'Behind the scenes of a community garden harvest') {
  const idea = sys.contentIdeaEngine.promoteContentIdea(
    sys.contentIdeaEngine.createContentIdea(text).id
  );
  return sys.contentConceptEngine.createContentConcept(idea);
}

let assetNonce = 0;
function importedAsset(sys, overrides = {}) {
  // importMedia short-circuits on a SHA256 hash of binaryContent (Test
  // Governance §14 dedup rule, 207_MediaEngine.js) — each test asset needs
  // genuinely distinct bytes, or unrelated test assets silently collapse
  // into one MediaAsset. A per-process counter guarantees distinct content
  // without callers having to remember to vary it themselves.
  assetNonce += 1;
  return sys.mediaEngine.importMedia(Object.assign(
    { binaryContent: Buffer.from('slice5 test bytes ' + assetNonce), mediaType: 'video', durationSec: 8, orientation: 'vertical' },
    overrides
  ));
}

/** Analyzes an asset, then (only if needed) patches just content_type — the
 * MockAIProvider.analyzeMedia heuristic always returns PRIMARY (documented
 * limitation of metadata-only Phase 1 analysis), so B_ROLL/IRRELEVANT
 * scenarios require this direct patch. Reuses the real analyzeMedia call for
 * everything else (versioning, latest_analysis_id linkage, status), so
 * nothing about that linkage is re-implemented here. */
function analyzedAsset(sys, { contentType = 'PRIMARY', assetOverrides = {} } = {}) {
  const asset = importedAsset(sys, assetOverrides);
  let analysis = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  if (contentType !== analysis.content_type) {
    sys.storage.update('media_analyses', analysis.id, { content_type: contentType });
    analysis = sys.mediaAnalysisEngine.get(analysis.id);
  }
  return { asset: sys.storage.read('media_assets', asset.id), analysis };
}

function readyPlan(sys, { conceptOverride, assetCount = 1 } = {}) {
  const concept = conceptOverride || readyConcept(sys);
  const assets = [];
  for (let i = 0; i < assetCount; i += 1) assets.push(analyzedAsset(sys).asset);
  const plan = sys.editPlanEngine.createEditPlan({
    conceptId: concept.id,
    mediaAssetIds: assets.map((a) => a.id),
  });
  return { concept, assets, plan };
}

// --- EditProject (Contract v1 §1, lazy creation) --------------------------

test('EditProject: lazy-created on the first createEditPlan for a Concept, reused (not duplicated) on subsequent calls', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const asset1 = analyzedAsset(sys).asset;
  const asset2 = analyzedAsset(sys).asset;

  const plan1 = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [asset1.id] });
  const project1 = sys.editPlanEngine.getEditProject(plan1.edit_project_id);
  assert.equal(project1.concept_id, concept.id);
  assert.equal(typeof project1.created_at, 'string');

  const plan2 = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [asset2.id] });
  assert.equal(plan2.edit_project_id, plan1.edit_project_id, 'second createEditPlan for the same Concept must reuse the same EditProject');

  const allProjectsForConcept = sys.storage.readAll('edit_projects', (p) => p.concept_id === concept.id);
  assert.equal(allProjectsForConcept.length, 1, 'EditProject must not be duplicated');
});

// --- EditPlan initial creation / 18-field schema / versioning -------------

test('EditPlan: initial creation reaches READY with all 18 schema fields, version 1, supersedes_version null', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys, { assetCount: 2 });

  assert.equal(plan.status, 'READY');
  assert.equal(plan.version, 1);
  assert.equal(plan.supersedes_version, null);
  assert.equal(typeof plan.id, 'string');
  assert.equal(typeof plan.edit_project_id, 'string');

  const expectedFields = [
    'plan_id', 'edit_project_id', 'version', 'target_duration_sec', 'platform_format',
    'narrative_structure', 'selected_clips', 'broll_insertions', 'captions', 'music',
    'audio_treatment', 'transitions', 'pacing_notes', 'reframing', 'status', 'generated_by',
    'supersedes_version', 'media_provenance',
  ];
  // plan_id is the AI Production Contract's abstract column name; the concrete
  // record's identity column is `id` (same reconciliation as MediaAnalysis's
  // own `id` vs. the Contract's `analysis_id`, per Contract v1 §3.1 note).
  expectedFields.filter((f) => f !== 'plan_id').forEach((field) => {
    assert.ok(Object.prototype.hasOwnProperty.call(plan, field), 'missing EditPlan field: ' + field);
  });
  assert.ok(Object.prototype.hasOwnProperty.call(plan, 'id'), 'EditPlan record must carry an id (plan_id column)');
  assert.equal(plan.selected_clips.length, 2);
  assert.ok(Array.isArray(plan.media_provenance));
});

test('EditPlan: revision creates version 2 under the same EditProject, with supersedes_version = 1', () => {
  const sys = buildSystem(freshDataDir());
  const { concept, plan: v1 } = readyPlan(sys);
  const asset2 = analyzedAsset(sys).asset;

  const v2 = sys.editPlanEngine.createEditPlan({
    revisionOf: v1.id,
    mediaAssetIds: [asset2.id],
    reviewFeedback: 'tighten the opening',
  });

  assert.equal(v2.version, 2);
  assert.equal(v2.supersedes_version, 1);
  assert.equal(v2.edit_project_id, v1.edit_project_id);
  assert.notEqual(v2.id, v1.id);

  const allVersions = sys.editPlanEngine.getAllForProject(v1.edit_project_id);
  assert.deepEqual(allVersions.map((p) => p.version), [1, 2]);
});

test('createEditPlan: rejects an unknown revisionOf id, a missing conceptId on initial creation, and an empty mediaAssetIds', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const asset = analyzedAsset(sys).asset;

  assert.throws(() => sys.editPlanEngine.createEditPlan({ revisionOf: 'no_such_plan', mediaAssetIds: [asset.id] }));
  assert.throws(() => sys.editPlanEngine.createEditPlan({ mediaAssetIds: [asset.id] }));
  assert.throws(() => sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [] }));
});

// --- Provenance capture (Contract v1 §2/§6, ADR-022 Decision — Provenance) -

test('extractDistinctAssetIds: one entry per distinct asset, deduplicated across selected_clips AND broll_insertions (unit test)', () => {
  const ids = EditPlan.extractDistinctAssetIds({
    selected_clips: [{ asset_id: 'a1' }, { asset_id: 'a2' }, { asset_id: 'a1' }],
    broll_insertions: [{ asset_id: 'a2' }, { asset_id: 'a3' }],
  });
  assert.deepEqual(ids, ['a1', 'a2', 'a3']);
});

test('Provenance: single selected asset produces exactly one media_provenance entry with the exact MediaAnalysis identity used', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 1 });

  assert.equal(plan.media_provenance.length, 1);
  assert.equal(plan.media_provenance[0].asset_id, assets[0].id);
  assert.equal(plan.media_provenance[0].analysis_id, assets[0].latest_analysis_id);
});

test('Provenance: multiple distinct selected assets each get their own entry', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 3 });

  assert.equal(plan.media_provenance.length, 3);
  const provenanceAssetIds = plan.media_provenance.map((p) => p.asset_id).sort();
  assert.deepEqual(provenanceAssetIds, assets.map((a) => a.id).sort());
});

test('Provenance: covers assets from BOTH selected_clips and broll_insertions', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const primary = analyzedAsset(sys, { contentType: 'PRIMARY' }).asset;
  const broll = analyzedAsset(sys, { contentType: 'B_ROLL' }).asset;

  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [primary.id, broll.id] });

  assert.equal(plan.selected_clips.length, 1);
  assert.equal(plan.broll_insertions.length, 1);
  const provenanceAssetIds = plan.media_provenance.map((p) => p.asset_id).sort();
  assert.deepEqual(provenanceAssetIds, [primary.id, broll.id].sort());
});

test('Provenance: an asset considered but classified IRRELEVANT is excluded from both the plan and its provenance', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const kept = analyzedAsset(sys, { contentType: 'PRIMARY' }).asset;
  const dropped = analyzedAsset(sys, { contentType: 'IRRELEVANT' }).asset;

  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [kept.id, dropped.id] });

  assert.equal(plan.selected_clips.some((c) => c.asset_id === dropped.id), false);
  assert.equal(plan.broll_insertions.some((b) => b.asset_id === dropped.id), false);
  assert.equal(plan.media_provenance.some((p) => p.asset_id === dropped.id), false);
  assert.equal(plan.media_provenance.some((p) => p.asset_id === kept.id), true);
});

test('Provenance: a revision captures FRESH provenance reflecting re-analysis, never inherited from the prior version', () => {
  const sys = buildSystem(freshDataDir());
  const { concept, plan: v1, assets } = readyPlan(sys, { assetCount: 1 });
  const asset = assets[0];
  const oldAnalysisId = v1.media_provenance[0].analysis_id;

  // Re-analyze the same asset (simulates new footage-quality info arriving).
  const newAnalysis = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  assert.notEqual(newAnalysis.id, oldAnalysisId);

  const v2 = sys.editPlanEngine.createEditPlan({ revisionOf: v1.id, mediaAssetIds: [asset.id] });

  assert.equal(v2.media_provenance[0].analysis_id, newAnalysis.id);
  assert.notEqual(v2.media_provenance[0].analysis_id, oldAnalysisId);
  // The old version's own provenance is untouched by the new version existing.
  const v1Reloaded = sys.editPlanEngine.get(v1.id);
  assert.equal(v1Reloaded.media_provenance[0].analysis_id, oldAnalysisId);
});

// --- Staleness / Unverifiable (ADR-022, Contract v1 §2/§5/§7/§8) ----------

test('checkProvenance: reports "current" when nothing has changed since plan creation', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys, { assetCount: 2 });

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  assert.equal(check.status, 'current');
  assert.ok(check.entries.every((e) => e.status === 'current'));
});

test('checkProvenance: reports "stale" (identity-based) once an asset has been re-analyzed after plan creation', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 1 });

  sys.mediaAnalysisEngine.analyzeMedia(assets[0].id); // asset re-analyzed AFTER plan creation

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  assert.equal(check.status, 'stale');
  assert.equal(check.entries[0].status, 'stale');
});

test('checkProvenance: reports "unverifiable" when a selected asset was never analyzed at all', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const unanalyzed = importedAsset(sys); // never analyzed: latest_analysis_id stays null

  const plan = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [unanalyzed.id] });
  assert.equal(plan.media_provenance[0].analysis_id, null);

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  assert.equal(check.status, 'unverifiable');
  assert.equal(check.entries[0].status, 'unverifiable');
});

test('checkProvenance: reports "unverifiable" when the recorded analysis_id no longer resolves to a real MediaAnalysis record', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys, { assetCount: 1 });

  // Simulate an unresolvable reference directly on the stored plan (no
  // command exists that produces this naturally, since MediaAnalysis is
  // append-only/never deleted — this isolates the resolution-failure branch
  // itself, matching how 606_/610_ isolate other otherwise-unreachable branches).
  sys.storage.update('edit_plans', plan.id, {
    media_provenance: [{ asset_id: plan.media_provenance[0].asset_id, analysis_id: 'does_not_exist' }],
  });

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  assert.equal(check.status, 'unverifiable');
});

test('checkProvenance: reports "unverifiable" when the referenced MediaAsset itself no longer resolves', () => {
  const sys = buildSystem(freshDataDir());
  const { plan } = readyPlan(sys, { assetCount: 1 });
  const validAnalysisId = plan.media_provenance[0].analysis_id;
  const phantomAssetId = 'asset_does_not_exist';

  // Closure-Gate-identified defensive branch (209_EditPlanEngine.js
  // checkProvenance, the `if (!asset)` check): StorageAdapterPort has no
  // delete operation (confirmed — grepped 001_ports.js, zero hits), so this
  // scenario cannot occur through any real command yet. It is fabricated
  // directly via existing storage.update, exactly like the sibling
  // unresolved-analysis test immediately above, rather than by adding
  // delete functionality (explicitly out of scope). selected_clips and
  // media_provenance must agree on the phantom id, or
  // extractDistinctAssetIds would never look this entry up in the first
  // place; analysis_id is left pointing at a real, resolvable MediaAnalysis
  // so this isolates ONLY the asset-missing branch, not the
  // analysis-missing branch already covered above.
  sys.storage.update('edit_plans', plan.id, {
    selected_clips: [{ asset_id: phantomAssetId, in: 0, out: 5, order: 0 }],
    media_provenance: [{ asset_id: phantomAssetId, analysis_id: validAnalysisId }],
  });

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  assert.equal(check.status, 'unverifiable');
  assert.equal(check.entries.length, 1);
  assert.equal(check.entries[0].asset_id, phantomAssetId);
  assert.equal(check.entries[0].status, 'unverifiable');
  assert.match(check.entries[0].reason, /MediaAsset no longer exists/);
});

test('stale and unverifiable are reported distinctly, never conflated, on a plan with one of each', () => {
  const sys = buildSystem(freshDataDir());
  const concept = readyConcept(sys);
  const willGoStale = analyzedAsset(sys).asset;
  const neverAnalyzed = importedAsset(sys);

  const plan = sys.editPlanEngine.createEditPlan({
    conceptId: concept.id,
    mediaAssetIds: [willGoStale.id, neverAnalyzed.id],
  });
  sys.mediaAnalysisEngine.analyzeMedia(willGoStale.id); // now stale

  const check = sys.editPlanEngine.checkProvenance(plan.id);
  const byAsset = Object.fromEntries(check.entries.map((e) => [e.asset_id, e.status]));
  assert.equal(byAsset[willGoStale.id], 'stale');
  assert.equal(byAsset[neverAnalyzed.id], 'unverifiable');
  // Overall status must reflect the more severe condition, never silently
  // collapsed to just "stale".
  assert.equal(check.status, 'unverifiable');
});

// --- Historical integrity (Contract v1 §3/§5, ADR-022 stale-plan handling) -

test('Historical integrity: a stale EditPlan remains retained and readable, and revising it never mutates it', () => {
  const sys = buildSystem(freshDataDir());
  const { plan: v1, assets } = readyPlan(sys, { assetCount: 1 });
  sys.mediaAnalysisEngine.analyzeMedia(assets[0].id); // v1 now stale
  const v1BeforeRevision = JSON.parse(JSON.stringify(sys.editPlanEngine.get(v1.id)));

  const v2 = sys.editPlanEngine.createEditPlan({ revisionOf: v1.id, mediaAssetIds: [assets[0].id] });

  const v1AfterRevision = sys.editPlanEngine.get(v1.id);
  assert.deepEqual(v1AfterRevision, v1BeforeRevision, 'revising a stale plan must not change one field of the source plan');
  assert.equal(sys.editPlanEngine.checkProvenance(v1.id).status, 'stale', 'source plan must remain stale, never silently "repaired" to current');
  assert.notEqual(v2.id, v1.id);
});

test('Historical integrity: checkProvenance is read-only — it never modifies the EditPlan, MediaAsset, or MediaAnalysis records it inspects', () => {
  const sys = buildSystem(freshDataDir());
  const { plan, assets } = readyPlan(sys, { assetCount: 1 });
  const planBefore = JSON.parse(JSON.stringify(sys.editPlanEngine.get(plan.id)));
  const assetBefore = JSON.parse(JSON.stringify(sys.storage.read('media_assets', assets[0].id)));

  sys.editPlanEngine.checkProvenance(plan.id);
  sys.editPlanEngine.checkProvenance(plan.id); // called twice — must still be a no-op

  assert.deepEqual(sys.editPlanEngine.get(plan.id), planBefore);
  assert.deepEqual(sys.storage.read('media_assets', assets[0].id), assetBefore);
});

// --- Authority boundary static checks (mirrors 610_'s pattern) ------------

test('EditPlanEngine source contains no Slice 6/Google-API/publication-authority concepts', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/209_EditPlanEngine.js'), 'utf8');
  ['ReviewEngine', 'FINAL_APPROVED', 'PUBLISHED', 'PublicationEngine', 'SpreadsheetApp', 'DriveApp', 'UrlFetchApp']
    .forEach((term) => assert.equal(source.includes(term), false, 'unexpected term in EditPlanEngine: ' + term));
});
