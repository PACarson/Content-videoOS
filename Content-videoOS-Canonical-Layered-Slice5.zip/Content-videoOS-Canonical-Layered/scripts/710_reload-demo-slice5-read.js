'use strict';

/**
 * 710_reload-demo-slice5-read.js
 *
 * Runs in a SEPARATE `node` process from 709_reload-demo-slice5-write.js.
 * Re-reads every id that process printed and confirms: the EditProject
 * persisted; EditPlan v1's own record is byte-for-byte identical to what it
 * was the moment before it went stale (never silently "repaired"); v1 is
 * still independently reported stale by a freshly constructed
 * EditPlanEngine in this new process (not a cached in-memory judgement
 * carried over from the write process); v2 is still current and its own
 * supersedes_version/provenance survived; and the EditVersion (rough cut
 * manifest) generated from v2 persisted correctly.
 *
 * Usage: node scripts/710_reload-demo-slice5-read.js <dataDir> <editPlanV1Id> <editPlanV2Id> <editVersionId>
 */
const { buildSystem } = require('../src/401_system');

const [, , dataDir, editPlanV1Id, editPlanV2Id, editVersionId] = process.argv;
if (!dataDir || !editPlanV1Id || !editPlanV2Id || !editVersionId) {
  console.error('Usage: node 710_reload-demo-slice5-read.js <dataDir> <editPlanV1Id> <editPlanV2Id> <editVersionId>');
  process.exit(1);
}

const sys = buildSystem(dataDir);

const v1 = sys.editPlanEngine.get(editPlanV1Id);
const v2 = sys.editPlanEngine.get(editPlanV2Id);
const roughCut = sys.editEngine.get(editVersionId);
const project = v1 ? sys.editPlanEngine.getEditProject(v1.edit_project_id) : null;

const v1Check = sys.editPlanEngine.checkProvenance(editPlanV1Id);
const v2Check = sys.editPlanEngine.checkProvenance(editPlanV2Id);

console.log(JSON.stringify({
  projectFound: !!project,
  v1Found: !!v1,
  v1Version: v1 ? v1.version : null,
  v1SupersedesVersion: v1 ? v1.supersedes_version : null,
  v1SerializedNow: v1 ? JSON.stringify(v1) : null,
  v1StatusInNewProcess: v1Check.status,
  v2Found: !!v2,
  v2Version: v2 ? v2.version : null,
  v2SupersedesVersion: v2 ? v2.supersedes_version : null,
  v2ProvenanceCount: v2 ? v2.media_provenance.length : null,
  v2StatusInNewProcess: v2Check.status,
  roughCutFound: !!roughCut,
  roughCutEditPlanId: roughCut ? roughCut.edit_plan_id : null,
  roughCutHasTimeline: roughCut ? Array.isArray(roughCut.manifest.timeline) : null,
}));
