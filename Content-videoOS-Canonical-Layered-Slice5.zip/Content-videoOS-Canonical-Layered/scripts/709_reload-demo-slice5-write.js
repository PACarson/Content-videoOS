'use strict';

/**
 * 709_reload-demo-slice5-write.js
 *
 * Slice 5 counterpart to 707/708 — a genuine two-process persistence
 * demonstration exercising the exact sequence Contract v1 §5 describes:
 * an initial EditPlan (v1), a re-analysis that makes v1 stale, a revision
 * (v2) with independently fresh provenance, and a successful
 * generateRoughCut on v2. 710_reload-demo-slice5-read.js runs as its own,
 * separate `node` process to confirm the EditProject, both EditPlan
 * versions (v1 still stale, v2 still current, v1's own record byte-for-byte
 * unchanged), and the EditVersion all survive a real process boundary — not
 * just an in-memory reference.
 *
 * Usage: node scripts/709_reload-demo-slice5-write.js <dataDir>
 */
const { buildSystem } = require('../src/401_system');

const dataDir = process.argv[2];
if (!dataDir) {
  console.error('Usage: node 709_reload-demo-slice5-write.js <dataDir>');
  process.exit(1);
}

const sys = buildSystem(dataDir);

const idea = sys.contentIdeaEngine.promoteContentIdea(
  sys.contentIdeaEngine.createContentIdea('Reload demo: Slice 5 two-process persistence').id
);
const concept = sys.contentConceptEngine.createContentConcept(idea);

const asset = sys.mediaEngine.importMedia({
  binaryContent: Buffer.from('reload-demo-slice5 binary payload — original footage bytes'),
  mediaType: 'video',
  durationSec: 10,
  orientation: 'vertical',
});

// Analyze BEFORE creating v1, so v1 starts out current/valid, not
// unverifiable — the demo is specifically about staleness, not the
// separate never-analyzed/unverifiable path (covered by test 611/612).
sys.mediaAnalysisEngine.analyzeMedia(asset.id);

const v1 = sys.editPlanEngine.createEditPlan({ conceptId: concept.id, mediaAssetIds: [asset.id] });
const v1BeforeStaling = JSON.stringify(sys.editPlanEngine.get(v1.id));

// Re-analyze AFTER v1 was created — this is what makes v1 stale.
sys.mediaAnalysisEngine.analyzeMedia(asset.id);

const v2 = sys.editPlanEngine.createEditPlan({ revisionOf: v1.id, mediaAssetIds: [asset.id], reviewFeedback: 'reload demo revision' });
const roughCut = sys.editEngine.generateRoughCut(v2.id);

console.log(JSON.stringify({
  editProjectId: v1.edit_project_id,
  conceptId: concept.id,
  mediaAssetId: asset.id,
  editPlanV1Id: v1.id,
  editPlanV2Id: v2.id,
  editVersionId: roughCut.id,
  v1BeforeStalingSerialized: v1BeforeStaling,
  v1StatusAtWriteTime: sys.editPlanEngine.checkProvenance(v1.id).status,
  v2StatusAtWriteTime: sys.editPlanEngine.checkProvenance(v2.id).status,
}));
