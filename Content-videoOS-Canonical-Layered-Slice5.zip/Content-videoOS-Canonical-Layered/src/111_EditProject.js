'use strict';

/**
 * 111_EditProject.js
 *
 * EditProject — the stable, non-versioned container per Concept that
 * EditPlan versions accumulate under (Architecture doc §2 Domain Model:
 * "1 per Concept"; ADR-002 — hangs off ContentConcept, no independent
 * identity apart from the Concept it belongs to).
 *
 * Per the Slice 5 Implementation Contract v1 §1/§5 (EditProject Contract):
 * this entity has no lifecycle/status field and is never versioned itself
 * — only its child EditPlan is. It is created lazily by EditPlanEngine the
 * first time createEditPlan() is called for a Concept that has none yet;
 * there is no separate createEditProject command (Contract v1 explicitly
 * rejects adding a speculative lifecycle field here without evidence of an
 * actual requirement).
 *
 * Pure domain module: no storage, no AI call. EditPlanEngine is the only
 * caller.
 */

function toRecord({ id, conceptId, now }) {
  return {
    id,
    concept_id: conceptId,
    created_at: now(),
  };
}

module.exports = { toRecord };
