'use strict';

const EditProject = require('./111_EditProject');
const EditPlan = require('./112_EditPlan');
const { runLifecycle } = require('./002_aiGenerationLifecycle');

const EDIT_PROJECT_COLLECTION = 'edit_projects';
const EDIT_PLAN_COLLECTION = 'edit_plans';
const MEDIA_ASSET_COLLECTION = 'media_assets';
const MEDIA_ANALYSIS_COLLECTION = 'media_analyses';
const CONCEPT_COLLECTION = 'content_concepts';

/**
 * 209_EditPlanEngine.js
 *
 * EditPlanEngine — Slice 5 (Slice 5 Implementation Contract v1, ADR-022).
 * Owns EditProject and EditPlan (Architecture doc §3). Depends only on
 * StorageAdapterPort + AIProviderPort + injected id/clock, never on a
 * concrete adapter (001_ports.js) — same discipline as every prior engine.
 *
 * Authority boundary (Contract v1 §8 / CVOS-P8): this engine produces
 * Decisions only. `createEditPlan` never executes anything — execution is
 * EditEngine's `generateRoughCut` (210_EditEngine.js), which calls this
 * engine's `checkProvenance` before proceeding and halts on anything but
 * `current`.
 */
class EditPlanEngine {
  constructor({ storage, aiProvider, eventLog, idGenerator, now }) {
    this.storage = storage;
    this.aiProvider = aiProvider;
    this.eventLog = eventLog;
    this.idGenerator = idGenerator;
    this.now = now;
  }

  /**
   * Contract v1 §1 (EditProject Contract) — lazy creation: called only from
   * createEditPlan's initial-creation path below, never exposed as its own
   * public command (there is no createEditProject).
   */
  _ensureEditProject(conceptId) {
    const existing = this.storage.readAll(EDIT_PROJECT_COLLECTION, (p) => p.concept_id === conceptId);
    if (existing.length > 0) return existing[0];

    const record = EditProject.toRecord({ id: this.idGenerator(), conceptId, now: this.now });
    const stored = this.storage.append(EDIT_PROJECT_COLLECTION, record);
    this.eventLog.record('EditProjectCreated', { id: stored.id, conceptId });
    return stored;
  }

  /**
   * Contract v1 §2/§6 (Provenance capture): looks up each asset's CURRENT
   * `latest_analysis_id` at the moment of capture. If an asset has never
   * been analyzed, `analysis_id` is recorded as null — which correctly
   * resolves to `unverifiable` later in checkProvenance, rather than being
   * silently treated as valid.
   */
  _captureProvenance(assetIds) {
    return assetIds.map((assetId) => {
      const asset = this.storage.read(MEDIA_ASSET_COLLECTION, assetId);
      return { asset_id: assetId, analysis_id: asset ? asset.latest_analysis_id : null };
    });
  }

  /**
   * Architecture §3: "Commands: createEditPlan (used for both the initial
   * plan and every revision)" — one command, distinguished by whether
   * `revisionOf` is supplied, not two separate methods.
   *
   * Initial: requires `conceptId`; an EditProject is lazily ensured for it.
   * Revision: requires `revisionOf` (an existing EditPlan id); `edit_project_id`
   * and the version number to supersede are both derived from that plan, not
   * re-supplied by the caller (avoids a caller-supplied conceptId silently
   * disagreeing with the plan's actual project).
   *
   * Contract v1 §5 (ADR-022 stale-plan-revision decision, EDITING/REVISION,
   * NOT EXECUTED-class): `revisionOf` is read here ONLY to derive
   * `edit_project_id` and the version to supersede. It is never checked for
   * staleness/unverifiable status, and this method never mutates it in any
   * way — the old plan's own record (including its own media_provenance) is
   * left exactly as it was, whatever its provenance status.
   */
  createEditPlan({ conceptId, mediaAssetIds, revisionOf, reviewFeedback } = {}) {
    let editProjectId;
    let supersedesVersion = null;
    let resolvedConceptId = conceptId;

    if (revisionOf) {
      const priorPlan = this.storage.read(EDIT_PLAN_COLLECTION, revisionOf);
      if (!priorPlan) throw new Error('EditPlan not found (revisionOf): ' + revisionOf);
      editProjectId = priorPlan.edit_project_id;
      supersedesVersion = priorPlan.version;
      const project = this.storage.read(EDIT_PROJECT_COLLECTION, editProjectId);
      resolvedConceptId = project ? project.concept_id : resolvedConceptId;
    } else {
      if (typeof conceptId !== 'string' || conceptId.trim().length === 0) {
        throw new Error('conceptId is required to create an initial EditPlan');
      }
      const project = this._ensureEditProject(conceptId);
      editProjectId = project.id;
    }

    if (!Array.isArray(mediaAssetIds) || mediaAssetIds.length === 0) {
      throw new Error('mediaAssetIds must be a non-empty array');
    }
    const candidates = mediaAssetIds.map((assetId) => {
      const asset = this.storage.read(MEDIA_ASSET_COLLECTION, assetId);
      if (!asset) throw new Error('MediaAsset not found: ' + assetId);
      const latestAnalysis = asset.latest_analysis_id
        ? this.storage.read(MEDIA_ANALYSIS_COLLECTION, asset.latest_analysis_id)
        : null;
      return { asset, latestAnalysis };
    });

    const concept = this.storage.read(CONCEPT_COLLECTION, resolvedConceptId);
    if (!concept) throw new Error('ContentConcept not found: ' + resolvedConceptId);

    const id = this.idGenerator();
    const lifecycleResult = runLifecycle({
      generate: () => this.aiProvider.generateEditPlan(concept, candidates, reviewFeedback || null),
      validate: (fields) => EditPlan.validateEditPlanFields(fields),
      meetsQualityBar: () => true,
      generatedBy: 'MockAIProvider',
      now: this.now,
    });

    // Contract v1 §6: captured fresh from THIS plan's own actual selection
    // against CURRENT latest_analysis_id — never inherited from `priorPlan`
    // above, whether or not this is a revision, whether or not the source
    // plan (if any) is itself stale/unverifiable.
    const mediaProvenance = lifecycleResult.status !== 'GENERATION_FAILED'
      ? this._captureProvenance(EditPlan.extractDistinctAssetIds(lifecycleResult.fields))
      : [];

    const existingVersions = this.storage.readAll(EDIT_PLAN_COLLECTION, (p) => p.edit_project_id === editProjectId);
    const nextVersion = existingVersions.reduce((max, p) => Math.max(max, p.version), 0) + 1;

    const record = EditPlan.toRecord({
      id,
      editProjectId,
      version: nextVersion,
      supersedesVersion,
      generatedBy: lifecycleResult.generatedBy,
      lifecycleResult,
      mediaProvenance,
    });
    const stored = this.storage.append(EDIT_PLAN_COLLECTION, record);

    this.eventLog.record('EditPlanCreated', {
      id: stored.id,
      editProjectId,
      version: nextVersion,
      revisionOf: revisionOf || null,
      status: stored.status,
    });

    return stored;
  }

  /**
   * ADR-022 / Contract v1 §7-§9 — always computed fresh, never read from a
   * stored flag (see 112_EditPlan.js header for why staleness is not a
   * persisted field). Read-only: never writes to the plan, the asset, or
   * any MediaAnalysis record. Called by EditEngine.generateRoughCut before
   * any EXECUTED-class action, and safe to call at any other time too
   * (e.g. to show a plan's current status without attempting execution).
   *
   * `unverifiable` takes priority over `stale` in the overall result if a
   * plan has a mix of the two across its distinct assets — ADR-022 treats
   * unverifiable as the more severe condition, never downgraded to stale.
   *
   * @returns {{planId: string, status: 'current'|'stale'|'unverifiable', entries: object[]}}
   */
  checkProvenance(planId) {
    const plan = this.storage.read(EDIT_PLAN_COLLECTION, planId);
    if (!plan) throw new Error('EditPlan not found: ' + planId);

    const distinctAssetIds = EditPlan.extractDistinctAssetIds(plan);
    const entries = [];
    let overallStatus = 'current';

    for (const assetId of distinctAssetIds) {
      const provEntry = (plan.media_provenance || []).find((p) => p.asset_id === assetId);

      if (!provEntry || !provEntry.analysis_id) {
        entries.push({ asset_id: assetId, status: 'unverifiable', reason: 'no resolvable provenance was recorded for this asset' });
        overallStatus = 'unverifiable';
        continue;
      }

      const analysisRecord = this.storage.read(MEDIA_ANALYSIS_COLLECTION, provEntry.analysis_id);
      if (!analysisRecord) {
        entries.push({ asset_id: assetId, status: 'unverifiable', reason: 'recorded analysis_id does not resolve to an existing MediaAnalysis record' });
        overallStatus = 'unverifiable';
        continue;
      }

      const asset = this.storage.read(MEDIA_ASSET_COLLECTION, assetId);
      if (!asset) {
        entries.push({ asset_id: assetId, status: 'unverifiable', reason: 'referenced MediaAsset no longer exists' });
        overallStatus = 'unverifiable';
        continue;
      }

      if (asset.latest_analysis_id !== provEntry.analysis_id) {
        entries.push({ asset_id: assetId, status: 'stale', reason: 'this MediaAsset has been re-analyzed since this EditPlan was created' });
        if (overallStatus === 'current') overallStatus = 'stale';
        continue;
      }

      entries.push({ asset_id: assetId, status: 'current' });
    }

    return { planId, status: overallStatus, entries };
  }

  /** Convenience read accessor, matching every prior Slice 1-4 engine. */
  get(id) {
    return this.storage.read(EDIT_PLAN_COLLECTION, id);
  }

  getEditProject(id) {
    return this.storage.read(EDIT_PROJECT_COLLECTION, id);
  }

  /** All EditPlan versions for one EditProject, oldest first by version. */
  getAllForProject(editProjectId) {
    return this.storage
      .readAll(EDIT_PLAN_COLLECTION, (p) => p.edit_project_id === editProjectId)
      .slice()
      .sort((a, b) => a.version - b.version);
  }
}

module.exports = { EditPlanEngine };
