'use strict';

/**
 * 113_EditVersion.js
 *
 * EditVersion — EditEngine's output (Architecture doc §3: EditEngine
 * "Persistence: Owns EditVersion"). No field-level schema for EditVersion
 * exists anywhere in the frozen AI Production Contract, the Architecture
 * doc, `27_`, ADR-022, or the Slice 5 Implementation Contract v1 — unlike
 * EditPlan's 18 named columns. This is therefore a minimal, intentionally
 * small implementation-level design (smallest shape that satisfies the
 * contract, Contract v1 §11/§13), not a literal reproduction of an existing
 * authoritative table.
 *
 * Carries no status field of any kind — in particular nothing resembling
 * FINAL_APPROVED/PUBLISHED, which the Contract v1 §8 AI/Human Authority
 * boundary reserves for Slice 6 (Review/Publication), never Slice 5.
 *
 * Pure domain module: no storage, no AI/provider call. EditEngine is the
 * only caller.
 */

function toRecord({ id, editPlanId, manifest, now }) {
  return {
    id,
    edit_plan_id: editPlanId,
    manifest,
    generated_at: now(),
  };
}

module.exports = { toRecord };
