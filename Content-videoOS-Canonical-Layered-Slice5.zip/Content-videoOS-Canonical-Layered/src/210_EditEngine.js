'use strict';

const EditVersion = require('./113_EditVersion');

const EDIT_PLAN_COLLECTION = 'edit_plans';
const EDIT_VERSION_COLLECTION = 'edit_versions';

/**
 * 210_EditEngine.js
 *
 * EditEngine — Slice 5 (Slice 5 Implementation Contract v1 §7/§9, ADR-022).
 * Owns EditVersion (Architecture doc §3). `generateRoughCut` is the one
 * EXECUTED-class action Slice 5 introduces (CVOS-P9) — no human approval
 * gate here (Phase 0D), but the ADR-022 provenance/staleness boundary must
 * still be enforced before it runs.
 *
 * Contract v1 §7/§11 (EditEngine / provider boundary, Issue-04): Phase 1
 * introduces NO video-rendering provider port. This engine's output is a
 * deterministic structured manifest, produced by plain local logic — same
 * precedent as EquipmentEngine/ADR-008. A real external renderer, if one is
 * ever integrated, is future work outside Slice 5 and would need its own
 * port, added then, not speculatively here.
 *
 * Depends on EditPlanEngine only for `checkProvenance` (avoids duplicating
 * that logic — EditPlanEngine owns EditPlan and is the natural place for
 * provenance-checking to live), plus StorageAdapterPort for EditVersion
 * persistence.
 */
class EditEngine {
  constructor({ storage, editPlanEngine, eventLog, idGenerator, now }) {
    this.storage = storage;
    this.editPlanEngine = editPlanEngine;
    this.eventLog = eventLog;
    this.idGenerator = idGenerator;
    this.now = now;
  }

  /**
   * Contract v1 §6/§9 — execution boundary. Before producing anything: the
   * plan must be READY, and its provenance must be freshly checked as
   * `current`. Stale or unverifiable halts with an explicit error and
   * persists nothing — no EditVersion, no event, and (per checkProvenance's
   * own read-only contract) no modification to the EditPlan, MediaAsset, or
   * MediaAnalysis records it inspected. There is no automatic repair or
   * refresh attempt anywhere in this path (Contract v1 §6 rule 7 / user
   * authorization §6.7 — "no silent repair or automatic provenance refresh
   * during execution").
   *
   * Important boundary this method exists to enforce (Contract v1 §5):
   * permission to *revise* a stale source plan (EditPlanEngine.createEditPlan)
   * never implies permission to *execute* it — this is the only path that
   * performs execution, and it applies the same halt rule regardless of
   * whether the plan being checked is a fresh initial plan or a revision.
   */
  generateRoughCut(editPlanId) {
    const plan = this.storage.read(EDIT_PLAN_COLLECTION, editPlanId);
    if (!plan) throw new Error('EditPlan not found: ' + editPlanId);

    if (plan.status !== 'READY') {
      throw new Error('generateRoughCut rejected: EditPlan ' + editPlanId + ' is ' + plan.status + ' (requires READY)');
    }

    const provenanceCheck = this.editPlanEngine.checkProvenance(editPlanId);
    if (provenanceCheck.status !== 'current') {
      const problems = provenanceCheck.entries.filter((e) => e.status !== 'current');
      throw new Error(
        'generateRoughCut halted: EditPlan ' + editPlanId + ' provenance is ' + provenanceCheck.status +
        ' — ' + JSON.stringify(problems)
      );
    }

    const manifest = this._buildManifest(plan);
    const record = EditVersion.toRecord({ id: this.idGenerator(), editPlanId, manifest, now: this.now });
    const stored = this.storage.append(EDIT_VERSION_COLLECTION, record);

    this.eventLog.record('RoughCutGenerated', { id: stored.id, editPlanId });
    return stored;
  }

  /**
   * Phase 1 manifest (Contract v1 §7/§10): a deterministic, ordered
   * structured representation, not a rendered video file. Timeline order
   * follows each clip's own `order` field, not insertion order, so the
   * result is stable regardless of how the AI Provider happened to list
   * `selected_clips`.
   */
  _buildManifest(plan) {
    const timeline = plan.selected_clips
      .slice()
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((clip) => ({ asset_id: clip.asset_id, in: clip.in, out: clip.out }));

    return {
      timeline,
      broll: plan.broll_insertions.slice(),
      captions: plan.captions,
      music: plan.music,
      audio_treatment: plan.audio_treatment,
      transitions: plan.transitions,
      pacing_notes: plan.pacing_notes,
      reframing: plan.reframing,
      target_duration_sec: plan.target_duration_sec,
      platform_format: plan.platform_format,
    };
  }

  /** Convenience read accessor, matching every prior Slice 1-4 engine. */
  get(id) {
    return this.storage.read(EDIT_VERSION_COLLECTION, id);
  }

  getAllForPlan(editPlanId) {
    return this.storage.readAll(EDIT_VERSION_COLLECTION, (v) => v.edit_plan_id === editPlanId);
  }
}

module.exports = { EditEngine };
