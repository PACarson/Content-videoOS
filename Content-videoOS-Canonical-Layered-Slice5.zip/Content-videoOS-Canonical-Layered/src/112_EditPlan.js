'use strict';

/**
 * 112_EditPlan.js
 *
 * EditPlan — AI Production Contract §F (17 authoritative columns) plus the
 * 18th column added by ADR-022 (`media_provenance`), per the Slice 5
 * Implementation Contract v1 §2 (Option A: one entry per distinct MediaAsset
 * actually used, `{asset_id, analysis_id}`).
 *
 * `status` reuses the AI Generation Lifecycle values (002_aiGenerationLifecycle.js
 * — Architecture doc §6: "reused for Concept, Script, Production Plan,
 * EditPlan"), same as every other AI-generated entity in this codebase. Unlike
 * ProductionPlan.production_state (ADR-015), EditPlan has no post-READY
 * human-authorization extension here — the next human-facing step (Rough Cut
 * Review) is Slice 6, out of scope for this file.
 *
 * Staleness/unverifiable classification is deliberately NOT a field stored on
 * this record (ADR-022 Decision — Staleness is a live comparison against a
 * MediaAsset's *current* `latest_analysis_id`, which can change after this
 * plan was created without this plan itself being touched; caching that
 * comparison here would itself go stale). See 209_EditPlanEngine.js#checkProvenance
 * for the always-computed-fresh check.
 *
 * Pure domain module: no storage, no AI call. EditPlanEngine is the only
 * caller.
 */

function validateEditPlanFields(fields) {
  const errors = [];

  if (!Array.isArray(fields.selected_clips) || fields.selected_clips.length === 0) {
    errors.push('selected_clips must be a non-empty array');
  } else {
    fields.selected_clips.forEach((clip, i) => {
      if (!clip || typeof clip.asset_id !== 'string' || clip.asset_id.trim().length === 0) {
        errors.push('selected_clips[' + i + '].asset_id must be a non-empty string');
      }
    });
  }

  if (!Array.isArray(fields.broll_insertions)) {
    errors.push('broll_insertions must be an array');
  } else {
    fields.broll_insertions.forEach((insertion, i) => {
      if (!insertion || typeof insertion.asset_id !== 'string' || insertion.asset_id.trim().length === 0) {
        errors.push('broll_insertions[' + i + '].asset_id must be a non-empty string');
      }
    });
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Contract v1 §6 / ADR-022 Decision — Provenance: the distinct-asset set
 * requiring provenance is the deduplicated union of asset_id across
 * selected_clips and broll_insertions, in that order — nothing else. An
 * asset the AI merely considered but did not place into either structure is
 * not part of this set (Contract v1 §2 rule 3).
 */
function extractDistinctAssetIds(fields) {
  const ids = [];
  const seen = new Set();
  const collect = (entries) => {
    if (!Array.isArray(entries)) return;
    entries.forEach((entry) => {
      const assetId = entry && entry.asset_id;
      if (typeof assetId === 'string' && assetId.length > 0 && !seen.has(assetId)) {
        seen.add(assetId);
        ids.push(assetId);
      }
    });
  };
  collect(fields.selected_clips);
  collect(fields.broll_insertions);
  return ids;
}

/**
 * `mediaProvenance` is always freshly captured by the engine for THIS
 * specific record (initial or revision alike) — never copied forward from
 * any other version. See 209_EditPlanEngine.js#createEditPlan.
 */
function toRecord({ id, editProjectId, version, supersedesVersion, generatedBy, lifecycleResult, mediaProvenance }) {
  const fields = lifecycleResult.fields || {};
  return {
    id,
    edit_project_id: editProjectId,
    version,
    target_duration_sec: fields.target_duration_sec !== undefined ? fields.target_duration_sec : null,
    platform_format: fields.platform_format || null,
    narrative_structure: fields.narrative_structure || null,
    selected_clips: Array.isArray(fields.selected_clips) ? fields.selected_clips : [],
    broll_insertions: Array.isArray(fields.broll_insertions) ? fields.broll_insertions : [],
    captions: fields.captions !== undefined ? fields.captions : [],
    music: fields.music !== undefined ? fields.music : null,
    audio_treatment: fields.audio_treatment || null,
    transitions: fields.transitions || null,
    pacing_notes: fields.pacing_notes || null,
    reframing: fields.reframing || null,
    status: lifecycleResult.status,
    generated_by: generatedBy,
    supersedes_version: supersedesVersion !== undefined ? supersedesVersion : null,
    // 18th column, ADR-022 / Contract v1 §2 (Option A).
    media_provenance: Array.isArray(mediaProvenance) ? mediaProvenance : [],
    createdAt: lifecycleResult.generatedAt,
    validationErrors: lifecycleResult.validationErrors,
  };
}

module.exports = { validateEditPlanFields, extractDistinctAssetIds, toRecord };
