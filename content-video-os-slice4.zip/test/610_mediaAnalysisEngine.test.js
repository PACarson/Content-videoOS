'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildSystem } = require('../src/401_system');
const { AIProviderPort } = require('../src/001_ports');

function freshDataDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'cvos-test-'));
}

function importedAsset(sys, overrides = {}) {
  return sys.mediaEngine.importMedia(Object.assign(
    { binaryContent: Buffer.from('media analysis test bytes'), mediaType: 'video', durationSec: 12, orientation: 'vertical' },
    overrides
  ));
}

// --- 18.1 Successful analysis ---------------------------------------------

test('analyzeMedia: creates a MediaAnalysis referencing the correct MediaAsset, with valid analysis data, version 1, and persists it', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys);

  const analysis = sys.mediaAnalysisEngine.analyzeMedia(asset.id);

  assert.equal(analysis.asset_id, asset.id);
  assert.equal(analysis.analysis_version, 1);
  assert.ok(['GOOD', 'ACCEPTABLE', 'POOR'].includes(analysis.quality));
  assert.ok(['PRIMARY', 'B_ROLL', 'BACKUP', 'IRRELEVANT'].includes(analysis.content_type));
  assert.ok(['GOOD', 'NOISY', 'CLIPPED', 'SILENT'].includes(analysis.audio_quality));
  assert.ok(['STABLE', 'SHAKY', 'BLURRED', 'OVEREXPOSED', 'UNDEREXPOSED'].includes(analysis.visual_quality));
  assert.ok(['HIGH', 'MEDIUM', 'LOW'].includes(analysis.relevance));
  assert.ok(Array.isArray(analysis.flags));
  assert.equal(typeof analysis.generated_by, 'string');
  assert.equal(typeof analysis.created_at, 'string');
  assert.deepEqual(sys.mediaAnalysisEngine.get(analysis.id), analysis);
});

test('analyzeMedia: advances MediaAsset.status to ANALYZED and sets latest_analysis_id, without touching other MediaAsset fields', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys);
  const analysis = sys.mediaAnalysisEngine.analyzeMedia(asset.id);

  const reloaded = sys.mediaEngine.get(asset.id);
  assert.equal(reloaded.status, 'ANALYZED');
  assert.equal(reloaded.latest_analysis_id, analysis.id);
  assert.equal(reloaded.hash, asset.hash);
  assert.equal(reloaded.source_file_ref, asset.source_file_ref);
});

// --- 18.2 Re-analysis (versioning) -----------------------------------------

test('analyzeMedia: re-analysis of the same MediaAsset creates version 2 without altering version 1', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys);

  const v1 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  const v2 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);

  assert.equal(v1.analysis_version, 1);
  assert.equal(v2.analysis_version, 2);
  assert.notEqual(v1.id, v2.id);

  const v1Reloaded = sys.mediaAnalysisEngine.get(v1.id);
  assert.deepEqual(v1Reloaded, v1, 'version 1 must be unchanged after version 2 is created');

  const all = sys.mediaAnalysisEngine.getAllForAsset(asset.id);
  assert.equal(all.length, 2);
  assert.deepEqual(all.map((a) => a.analysis_version), [1, 2]);
});

test('analyzeMedia: latest_analysis_id tracks the newest version after re-analysis', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys);
  sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  const v2 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  assert.equal(sys.mediaEngine.get(asset.id).latest_analysis_id, v2.id);
});

// --- 18.3 MediaAsset immutability -------------------------------------------

test('analyzeMedia: MediaAsset identity fields (id, hash, source_file_ref, media_type, duration_sec, orientation, Shoot/Shot/Take/Equipment refs) are unchanged by analysis', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys, { shootId: 's1', shotId: 'sh1', takeId: 't1', equipmentId: 'eq1' });
  const before = Object.assign({}, asset);

  sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  const after = sys.mediaEngine.get(asset.id);

  for (const field of ['id', 'hash', 'source_file_ref', 'media_type', 'duration_sec', 'orientation', 'shoot_id', 'shot_id', 'take_id', 'equipment_id', 'capture_timestamp']) {
    assert.equal(after[field], before[field], field + ' must not change');
  }
});

// --- 18.4 Original media (binary) immutability ------------------------------

test('analyzeMedia: the original binary is unchanged and still retrievable byte-for-byte after analysis', () => {
  const sys = buildSystem(freshDataDir());
  const bytes = Buffer.from('untouched original binary content');
  const asset = sys.mediaEngine.importMedia({ binaryContent: bytes, mediaType: 'video', durationSec: 5, orientation: 'vertical' });

  sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  sys.mediaAnalysisEngine.analyzeMedia(asset.id); // twice, for good measure

  const retrieved = sys.mediaEngine.retrieveBinary(asset.id);
  assert.equal(Buffer.compare(retrieved, bytes), 0);
});

// --- 18.5 AI provider failure ------------------------------------------------

test('analyzeMedia: an AI provider exception leaves no MediaAnalysis record, no MediaAnalyzed event, and the MediaAsset untouched', () => {
  const brokenProvider = new (class extends AIProviderPort {
    analyzeMedia() { throw new Error('simulated provider outage'); }
  })();
  const sys = buildSystem(freshDataDir(), { aiProvider: brokenProvider });
  const asset = importedAsset(sys);

  assert.throws(() => sys.mediaAnalysisEngine.analyzeMedia(asset.id), /simulated provider outage/);

  assert.equal(sys.mediaAnalysisEngine.getAllForAsset(asset.id).length, 0);
  assert.equal(sys.eventLog.all((e) => e.type === 'MediaAnalyzed').length, 0);
  const reloaded = sys.mediaEngine.get(asset.id);
  assert.equal(reloaded.status, 'IMPORTED', 'must not silently advance to ANALYZED on failure');
  assert.equal(reloaded.latest_analysis_id, null);
});

test('analyzeMedia: a prior successful analysis survives a later failed attempt', () => {
  const workingProvider = new (require('../src/adapters/302_MockAIProvider').MockAIProvider)();
  let shouldFail = false;
  const flakyProvider = new (class extends AIProviderPort {
    analyzeMedia(asset) {
      if (shouldFail) throw new Error('simulated transient failure');
      return workingProvider.analyzeMedia(asset);
    }
  })();
  const sys = buildSystem(freshDataDir(), { aiProvider: flakyProvider });
  const asset = importedAsset(sys);

  const v1 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  shouldFail = true;
  assert.throws(() => sys.mediaAnalysisEngine.analyzeMedia(asset.id));

  assert.deepEqual(sys.mediaAnalysisEngine.get(v1.id), v1);
  assert.equal(sys.mediaAnalysisEngine.getAllForAsset(asset.id).length, 1);
  assert.equal(sys.mediaEngine.get(asset.id).latest_analysis_id, v1.id, 'must still point at the last successful version');
});

test('analyzeMedia: rejects a malformed/incomplete AI provider response rather than persisting it', () => {
  const brokenProvider = new (class extends AIProviderPort {
    analyzeMedia() { return { quality: 'NOT_A_REAL_VALUE' }; }
  })();
  const sys = buildSystem(freshDataDir(), { aiProvider: brokenProvider });
  const asset = importedAsset(sys);

  assert.throws(() => sys.mediaAnalysisEngine.analyzeMedia(asset.id), /malformed/);
  assert.equal(sys.mediaAnalysisEngine.getAllForAsset(asset.id).length, 0);
});

// --- 18.6 Provider boundary ---------------------------------------------------

test('analyzeMedia: goes through the AIProviderPort abstraction — a Mock provider is sufficient, no real external AI call is made', () => {
  const sys = buildSystem(freshDataDir());
  assert.ok(sys.aiProvider instanceof AIProviderPort);
  const asset = importedAsset(sys);
  assert.doesNotThrow(() => sys.mediaAnalysisEngine.analyzeMedia(asset.id));
});

// --- 18.7 Invalid input --------------------------------------------------------

test('analyzeMedia: rejects a nonexistent MediaAsset id', () => {
  const sys = buildSystem(freshDataDir());
  assert.throws(() => sys.mediaAnalysisEngine.analyzeMedia('does-not-exist'), /not found/);
});

// --- 18.8 Event correctness -----------------------------------------------------

test('MediaAnalyzed is recorded to the shared EventLog exactly once per successful analysis, with the correct version', () => {
  const sys = buildSystem(freshDataDir());
  const asset = importedAsset(sys);
  const v1 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  const v2 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);

  const events = sys.eventLog.all((e) => e.type === 'MediaAnalyzed' && e.payload.assetId === asset.id);
  assert.equal(events.length, 2);
  assert.equal(events[0].payload.id, v1.id);
  assert.equal(events[0].payload.version, 1);
  assert.equal(events[1].payload.id, v2.id);
  assert.equal(events[1].payload.version, 2);
});

// --- G2 boundary (17_...md) — analyzeMedia must not touch Take/verifyTake -----

test('analyzeMedia operates only on MediaAsset — it does not read or require any Take, and does not call verifyTake', () => {
  const sys = buildSystem(freshDataDir());
  // No Shoot/Take is created at all in this test — analyzeMedia must still work
  // from an imported MediaAsset alone, proving it has no Take dependency.
  const asset = importedAsset(sys); // shootId/shotId/takeId all default to null
  assert.equal(asset.take_id, null);
  const analysis = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
  assert.equal(analysis.asset_id, asset.id);
});

// --- Static boundary checks (matches 609_mediaEngine.test.js's pattern) ------

test('Domain/Engine code never references Google-specific runtime APIs', () => {
  const src = fs.readFileSync(require.resolve('../src/208_MediaAnalysisEngine.js'), 'utf8');
  assert.ok(!/DriveApp|SpreadsheetApp|UrlFetchApp|ScriptApp/.test(src));
});

test('MediaAnalysisEngine does not implement or reference any Slice 5/6 concept (EditPlan, RoughCut, Review, Publication, Analytics)', () => {
  const src = fs.readFileSync(require.resolve('../src/208_MediaAnalysisEngine.js'), 'utf8');
  assert.ok(!/EditPlan|RoughCut|ReviewEngine|Publication|AnalyticsEngine/.test(src));
});

test('MediaAnalysisEngine cannot authorize Production Go or change ProductionPlan.production_state', () => {
  // A bare string search would also flag this file's own explanatory
  // comment ("this engine never sets ProductionPlan.production_state") as
  // a false positive — check for an actual assignment/write, not the
  // words appearing at all (matches this project's established
  // RECAPTURE_NEEDED-in-comments precedent, 15_...md §13).
  const src = fs.readFileSync(require.resolve('../src/208_MediaAnalysisEngine.js'), 'utf8');
  assert.ok(!/\.production_state\s*=|production_state:\s*['"]AUTHORIZED['"]/.test(src));
});
