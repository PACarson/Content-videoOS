'use strict';

/**
 * 707_reload-demo-slice4-write.js
 *
 * Slice 4 counterpart to 705/706 — a genuine two-process persistence
 * demonstration through importMedia -> analyzeMedia (twice, to prove
 * versioning survives a process boundary too). 708_reload-demo-slice4-read.js
 * runs as its own, separate `node` process to confirm MediaAnalysis v1, v2,
 * and the MediaAsset's status/latest_analysis_id all survive a real process
 * boundary, not just an in-memory reference.
 *
 * Usage: node scripts/707_reload-demo-slice4-write.js <dataDir>
 */
const { buildSystem } = require('../src/401_system');

const dataDir = process.argv[2];
if (!dataDir) {
  console.error('Usage: node 707_reload-demo-slice4-write.js <dataDir>');
  process.exit(1);
}

const sys = buildSystem(dataDir);

const originalBytes = Buffer.from('reload-demo-slice4 binary payload — unanalyzed footage bytes');
const asset = sys.mediaEngine.importMedia({
  binaryContent: originalBytes,
  mediaType: 'video',
  durationSec: 9,
  orientation: 'vertical',
});

const analysisV1 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);
const analysisV2 = sys.mediaAnalysisEngine.analyzeMedia(asset.id);

console.log(JSON.stringify({
  mediaAssetId: asset.id,
  analysisV1Id: analysisV1.id,
  analysisV2Id: analysisV2.id,
  originalBytesBase64: originalBytes.toString('base64'),
}));
