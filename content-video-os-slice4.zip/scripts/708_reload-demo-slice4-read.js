'use strict';

/**
 * 708_reload-demo-slice4-read.js
 *
 * Runs in a SEPARATE `node` process from 707_reload-demo-slice4-write.js.
 * Re-reads every id that process printed and confirms MediaAsset status/
 * latest_analysis_id and both MediaAnalysis versions — including the
 * original imported binary content — all survive a real process boundary.
 *
 * Usage: node scripts/708_reload-demo-slice4-read.js <dataDir> <mediaAssetId> <analysisV1Id> <analysisV2Id>
 */
const { buildSystem } = require('../src/401_system');

const [, , dataDir, mediaAssetId, analysisV1Id, analysisV2Id] = process.argv;
if (!dataDir || !mediaAssetId || !analysisV1Id || !analysisV2Id) {
  console.error('Usage: node 708_reload-demo-slice4-read.js <dataDir> <mediaAssetId> <analysisV1Id> <analysisV2Id>');
  process.exit(1);
}

const sys = buildSystem(dataDir);

const media = sys.mediaEngine.get(mediaAssetId);
const retrievedBytes = sys.mediaEngine.retrieveBinary(mediaAssetId);
const v1 = sys.mediaAnalysisEngine.get(analysisV1Id);
const v2 = sys.mediaAnalysisEngine.get(analysisV2Id);
const allVersions = sys.mediaAnalysisEngine.getAllForAsset(mediaAssetId);

console.log(JSON.stringify({
  mediaFound: !!media,
  mediaStatus: media ? media.status : null,
  mediaLatestAnalysisId: media ? media.latest_analysis_id : null,
  retrievedBytesBase64: retrievedBytes.toString('base64'),
  v1Found: !!v1,
  v1Version: v1 ? v1.analysis_version : null,
  v2Found: !!v2,
  v2Version: v2 ? v2.analysis_version : null,
  totalVersionsForAsset: allVersions.length,
}));
