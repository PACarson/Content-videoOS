'use strict';

const MediaAnalysis = require('./110_MediaAnalysis');

const MEDIA_ASSET_COLLECTION = 'media_assets';
const MEDIA_ANALYSIS_COLLECTION = 'media_analyses';

/**
 * 208_MediaAnalysisEngine.js
 *
 * MediaAnalysisEngine — Slice 4 (Slice 4 Implementation Authorization Gate,
 * 18_...md). Owns `analyzeMedia`: AI-assisted analysis of an already-imported
 * MediaAsset, producing a new versioned MediaAnalysis record.
 *
 * Domain boundary (G2, 17_...md — CLOSED, not reopened here): this engine
 * reads MediaAsset, never Take.technicalMetadata. It never calls or
 * duplicates ShootEngine.verifyTake, and Slice 3 files are not touched by
 * this file's existence.
 *
 * AI authority (ADR-010; AI Production Contract AI Authority table, "AI
 * Media Analyst"): output is informational/Recommendation only — this
 * engine never sets ProductionPlan.production_state, never starts or
 * completes a Shoot, never approves a Take or Shot, and never mutates or
 * deletes the original MediaAsset binary. `MediaAsset.status -> 'ANALYZED'`
 * is a record-keeping marker, not an approval.
 *
 * Failure semantics (18_...md §16): a failed/invalid AI response throws
 * before anything is persisted — no MediaAnalysis record, no MediaAnalyzed
 * event, MediaAsset and any prior successful MediaAnalysis for it are left
 * exactly as they were. This deliberately does NOT reuse
 * 002_aiGenerationLifecycle.js's AI_GENERATED/.../GENERATION_FAILED wrapper:
 * the authoritative 11-column MediaAnalysis contract has no `status` column
 * to carry those states, and adding one would be an undocumented column
 * (Slice 4 Implementation Authorization Gate, 18_...md §8/§16 — "prefer the
 * approach that does not change the schema").
 */
class MediaAnalysisEngine {
  constructor({ storage, aiProvider, eventLog, idGenerator, now }) {
    this.storage = storage;
    this.aiProvider = aiProvider;
    this.eventLog = eventLog;
    this.idGenerator = idGenerator;
    this.now = now;
  }

  /**
   * Re-analysis (Idempotency Assessment, 18_...md §17): calling this again
   * for the same MediaAsset always creates the next version; it never
   * overwrites an earlier MediaAnalysis. That makes repeated/duplicate
   * calls safe by construction — there is nothing to deduplicate.
   */
  analyzeMedia(assetId) {
    const asset = this.storage.read(MEDIA_ASSET_COLLECTION, assetId);
    if (!asset) throw new Error('MediaAsset not found: ' + assetId);

    // Provider exceptions propagate untouched from here: nothing below has
    // run yet, so no MediaAnalysis is created and no event fires.
    const outcome = this.aiProvider.analyzeMedia(asset);

    const validation = MediaAnalysis.validateMediaAnalysisFields(outcome || {});
    if (!validation.valid) {
      throw new Error('analyzeMedia rejected: malformed AI provider response — ' + validation.errors.join('; '));
    }

    const priorVersions = this.storage.readAll(MEDIA_ANALYSIS_COLLECTION, (a) => a.asset_id === assetId);
    const nextVersion = priorVersions.reduce((max, a) => Math.max(max, a.analysis_version), 0) + 1;

    const record = MediaAnalysis.toRecord({
      id: this.idGenerator(),
      assetId,
      version: nextVersion,
      quality: outcome.quality,
      contentType: outcome.content_type,
      audioQuality: outcome.audio_quality,
      visualQuality: outcome.visual_quality,
      relevance: outcome.relevance,
      flags: outcome.flags,
      generatedBy: outcome.generated_by || 'unknown',
      now: this.now,
    });
    const stored = this.storage.append(MEDIA_ANALYSIS_COLLECTION, record);

    // Record-keeping only (see class comment) — not an approval, and does
    // not touch source_file_ref or any other MediaAsset identity field.
    this.storage.update(MEDIA_ASSET_COLLECTION, assetId, {
      status: 'ANALYZED',
      latest_analysis_id: stored.id,
    });

    this.eventLog.record('MediaAnalyzed', { id: stored.id, assetId, version: nextVersion });
    return stored;
  }

  /** Convenience read accessor, matching the other Slice 1-3 engines. */
  get(id) {
    return this.storage.read(MEDIA_ANALYSIS_COLLECTION, id);
  }

  /** All MediaAnalysis versions for one MediaAsset, oldest first by version. */
  getAllForAsset(assetId) {
    return this.storage
      .readAll(MEDIA_ANALYSIS_COLLECTION, (a) => a.asset_id === assetId)
      .slice()
      .sort((a, b) => a.analysis_version - b.analysis_version);
  }
}

module.exports = { MediaAnalysisEngine };
