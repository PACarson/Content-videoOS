'use strict';

/**
 * 110_MediaAnalysis.js
 *
 * MediaAnalysis — AI-generated, versioned observations about a MediaAsset
 * (AI Production Contract's 11-column MediaAnalysis schema; Product
 * Understanding Report: "AI-generated, versioned observations about a
 * MediaAsset"). Pure domain module, same shape as every other Slice 1-3
 * entity module (109_MediaAsset.js is the closest sibling).
 *
 * Field naming note: the Contract's own table calls the primary-key column
 * "analysis_id". Every entity in this codebase (ContentIdea, ..., MediaAsset)
 * instead uses a plain `id` primary key — the same reconciliation ADR-015
 * already made for `production_state` vs. the generic Contract's `status`
 * column. This file follows the established `id` convention rather than
 * introducing the one inconsistent field name in the codebase; the 11
 * columns are otherwise reproduced exactly (see Slice 4 Implementation
 * Authorization Gate, 18_...md §8 — no invented columns).
 *
 * `analyzeMedia`'s input is the imported MediaAsset itself, never
 * `Take.technicalMetadata` — that boundary is `verifyTake`'s (Slice 3), and
 * is closed governance (Slice 4 G2 Semantic Resolution, 17_...md).
 *
 * Append-only: a MediaAsset accumulates `MediaAnalysis` v1, v2, v3... —
 * re-analysis never overwrites a previous version (01_ Implementation Map
 * §1 "MediaAnalysisEngine" Tests bullet). This module never mutates an
 * existing MediaAnalysis record once created.
 */

const VALID_QUALITY = ['GOOD', 'ACCEPTABLE', 'POOR'];
const VALID_CONTENT_TYPE = ['PRIMARY', 'B_ROLL', 'BACKUP', 'IRRELEVANT'];
const VALID_AUDIO_QUALITY = ['GOOD', 'NOISY', 'CLIPPED', 'SILENT'];
const VALID_VISUAL_QUALITY = ['STABLE', 'SHAKY', 'BLURRED', 'OVEREXPOSED', 'UNDEREXPOSED'];
const VALID_RELEVANCE = ['HIGH', 'MEDIUM', 'LOW'];

function validateMediaAnalysisFields({ quality, content_type: contentType, audio_quality: audioQuality, visual_quality: visualQuality, relevance, flags }) {
  const errors = [];
  if (!VALID_QUALITY.includes(quality)) errors.push('quality must be one of: ' + VALID_QUALITY.join(', '));
  if (!VALID_CONTENT_TYPE.includes(contentType)) errors.push('content_type must be one of: ' + VALID_CONTENT_TYPE.join(', '));
  if (!VALID_AUDIO_QUALITY.includes(audioQuality)) errors.push('audio_quality must be one of: ' + VALID_AUDIO_QUALITY.join(', '));
  if (!VALID_VISUAL_QUALITY.includes(visualQuality)) errors.push('visual_quality must be one of: ' + VALID_VISUAL_QUALITY.join(', '));
  if (!VALID_RELEVANCE.includes(relevance)) errors.push('relevance must be one of: ' + VALID_RELEVANCE.join(', '));
  if (!Array.isArray(flags)) errors.push('flags must be an array');
  return { valid: errors.length === 0, errors };
}

/** All 11 authoritative columns — nothing added, nothing dropped. */
function toRecord({
  id, assetId, version, quality, contentType, audioQuality, visualQuality,
  relevance, flags, generatedBy, now,
}) {
  return {
    id,
    asset_id: assetId,
    analysis_version: version,
    quality,
    content_type: contentType,
    audio_quality: audioQuality,
    visual_quality: visualQuality,
    relevance,
    flags: Array.isArray(flags) ? flags.slice() : [],
    generated_by: generatedBy,
    created_at: now(),
  };
}

module.exports = {
  validateMediaAnalysisFields,
  toRecord,
  VALID_QUALITY,
  VALID_CONTENT_TYPE,
  VALID_AUDIO_QUALITY,
  VALID_VISUAL_QUALITY,
  VALID_RELEVANCE,
};
